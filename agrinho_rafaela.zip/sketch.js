let player;
let scene = 'field'; // Pode ser 'field' (campo) ou 'city' (cidade)

let trees = []; // Array para armazenar as árvores
let buildings = []; // Array para armazenar os prédios

function setup() {
  createCanvas(800, 600);
  player = new Player(width / 2, height / 2, 20); // Cria o jogador no centro da tela

  // Gera algumas árvores aleatórias no campo
  for (let i = 0; i < 10; i++) {
    trees.push(new Tree(random(width), random(height)));
  }

  // Gera alguns prédios aleatórios na cidade
  for (let i = 0; i < 7; i++) {
    buildings.push(new Building(random(width), random(height), random(50, 150), random(80, 250)));
  }
}

function draw() {
  if (scene === 'field') {
    drawFieldScene();
  } else if (scene === 'city') {
    drawCityScene();
  }

  player.update();
  player.display();

  checkSceneTransition();
}

// --- Funções de Desenho de Cenas ---

function drawFieldScene() {
  background(135, 206, 235); // Céu azul
  fill(124, 252, 0); // Verde para a grama
  rect(0, height / 2, width, height / 2); // Grama

  // Desenha as árvores
  for (let tree of trees) {
    tree.display();
  }

  // Desenha um "portal" para a cidade
  fill(100);
  ellipse(width - 50, height / 2, 80, 80);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(16);
  text('Cidade', width - 50, height / 2);
}

function drawCityScene() {
  background(173, 216, 230); // Céu mais claro
  fill(100); // Asfalto ou rua
  rect(0, height / 2, width, height / 2);

  // Desenha os prédios
  for (let building of buildings) {
    building.display();
  }

  // Desenha um "portal" para o campo
  fill(124, 252, 0);
  ellipse(50, height / 2, 80, 80);
  fill(0);
  textAlign(CENTER, CENTER);
  textSize(16);
  text('Campo', 50, height / 2);
}

// --- Classes do Jogo ---

class Player {
  constructor(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.speed = 5;
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }

    // Mantém o jogador dentro da tela
    this.x = constrain(this.x, this.r, width - this.r);
    this.y = constrain(this.y, this.r, height - this.r);
  }

  display() {
    fill(255, 0, 0); // Vermelho para o jogador
    ellipse(this.x, this.y, this.r * 2);
  }

  // Verifica se o jogador está sobre uma determinada área
  collidesWith(x, y, w, h) {
    return this.x > x && this.x < x + w && this.y > y && this.y < y + h;
  }
}

class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.trunkHeight = random(40, 80);
    this.foliageRadius = random(20, 40);
  }

  display() {
    // Tronco
    fill(139, 69, 19); // Marrom
    rect(this.x - 5, this.y - this.trunkHeight, 10, this.trunkHeight);
    // Folhagem
    fill(34, 139, 34); // Verde escuro
    ellipse(this.x, this.y - this.trunkHeight - this.foliageRadius / 2, this.foliageRadius * 2, this.foliageRadius * 2);
  }
}

class Building {
  constructor(x, y, w, h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }

  display() {
    fill(150); // Cinza para o prédio
    rect(this.x, this.y, this.w, this.h);
    // Janelas
    fill(200, 200, 0); // Amarelo para janelas
    let numWindowsX = floor(this.w / 20);
    let numWindowsY = floor(this.h / 30);
    for (let i = 0; i < numWindowsX; i++) {
      for (let j = 0; j < numWindowsY; j++) {
        rect(this.x + 5 + i * 15, this.y + 5 + j * 25, 10, 20);
      }
    }
  }
}

// --- Lógica de Transição de Cenas ---

function checkSceneTransition() {
  if (scene === 'field') {
    // Se o jogador estiver perto do portal da cidade
    let d = dist(player.x, player.y, width - 50, height / 2);
    if (d < player.r + 40) { // 40 é o raio do portal
      scene = 'city';
      player.x = 100; // Posiciona o jogador no lado oposto na nova cena
    }
  } else if (scene === 'city') {
    // Se o jogador estiver perto do portal do campo
    let d = dist(player.x, player.y, 50, height / 2);
    if (d < player.r + 40) { // 40 é o raio do portal
      scene = 'field';
      player.x = width - 100; // Posiciona o jogador no lado oposto na nova cena
    }
  }
}